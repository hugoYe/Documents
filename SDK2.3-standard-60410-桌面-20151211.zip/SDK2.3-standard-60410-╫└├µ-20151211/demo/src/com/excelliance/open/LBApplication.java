package com.excelliance.open;
import android.content.ContextWrapper;
import android.app.Application;
import android.content.Context;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import com.excelliance.kxqp.sdk.GameSdk;
import com.excelliance.open.VersionManager;

public class LBApplication extends Application {
    private VersionManager vm = null;
    private final String TAG = "PKApplication";
    private String newPath = null;
    private boolean runOnVm = false;
    
    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate runOnVm="+runOnVm+" @"+this);
        if (!GlobalSettings.USE_LEBIAN || newPath==null || runOnVm) {
            Log.d(TAG, "super.onCreate");
            super.onCreate();
        }
        if (!runOnVm)
            GameSdk.pkAppOnCreate(this, newPath);
    }

    @Override
    protected void attachBaseContext(Context base) {
        GlobalSettings.refreshState();
        if (GlobalSettings.USE_LEBIAN) {
            runOnVm = GameSdk.isRunningOnVm(null);
            Log.d(TAG, "attachBaseContext runOnVm="+runOnVm+" @"+this);
            if (runOnVm) {
                super.attachBaseContext(base);
                return;
            }
            
            try {
                Field mBase = ContextWrapper.class.getDeclaredField("mBase");
                mBase.setAccessible(true);
                mBase.set(this, base);
            } catch (Exception ignored) {
            }

            vm = VersionManager.getInstance();
            vm.pkInit(base);
            newPath = vm.getNewVersionPath();
            Log.d(TAG, "newPath="+newPath);
            if (newPath == null) {
                try {
                    Field mBase = ContextWrapper.class.getDeclaredField("mBase");
                    mBase.setAccessible(true);
                    mBase.set(this, null);
                }
                catch (Exception ignored) {
                }

                super.attachBaseContext(base);
            }
        }
        else {
            super.attachBaseContext(base);
        }
    }
}


