package com.demo.pk;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;

import com.excelliance.kxqp.sdk.GameSdk;
import com.excelliance.kxqp.sdk.IQueryUpdateCallback;

public class MainActivity extends Activity
{
    private final String TAG = "MainActivity";
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Log.d(TAG, "MainActivity onCreate savedInstanceState="+savedInstanceState);
        if (savedInstanceState == null) {
            final IQueryUpdateCallback callBack = new IQueryUpdateCallback() {
                public void onUpdateResult(int result) {
                    Log.d(TAG, "result="+result);
                }
            };
            GameSdk.queryUpdate(this, callBack);
        }

    }
}
