package com.excelliance.open;

public class GlobalSettings {
	public static boolean INSTALL_SHORTCUT = false;
	public static boolean USE_LEBIAN = true;
	public static boolean SHOW_BACKGROUND = true;
    public static void refreshState() {
        //USE_LEBIAN = !(new java.io.File("/sdcard/disable_LB_flag").exists());
        android.util.Log.d("GlobalSettings", "USE_LEBIAN="+USE_LEBIAN);
    }
}

